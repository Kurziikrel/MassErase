using BepInEx;
using BepInEx.Configuration;
using BepInEx.Logging;
using HarmonyLib;
using MassErase.Configuration;
using UnityEngine;

namespace MassErase
{
    [BepInPlugin(MyGUID, PluginName, VersionString)]
    public class MassEraseMod : BaseUnityPlugin
    {

        private const string MyGUID = "com.olivi.MassErase";
        private const string PluginName = "MassErase";
        private const string VersionString = "1.0.0";

        private static Harmony _harmony = new Harmony(MyGUID);
        private static MassEraseMod _instance;

        public static ManualLogSource Log = new ManualLogSource(PluginName);
        public static MassEraseMod Instance => _instance;

        public ConfigRegistry ModConfig;

        private void Awake()
        {
            gameObject.hideFlags = HideFlags.HideAndDontSave;
            _instance = this;
            Logger.LogInfo($"{PluginName} [{VersionString}] is loading...");
            Log = Logger;
            Log.LogInfo($"Plugin Awake()");
            ModConfig = new ConfigRegistry(Config, MyGUID);
            ModConfig.SetupConfigs();
            _harmony.PatchAll();
        }

        private void Start()
        {
            Log.LogInfo($"Plugin Start()");
        }

        

        private void OnDestroy()
        {
            Log.LogInfo($"Plugin OnDestroy()");
            var components = gameObject.GetComponents<BaseUnityPlugin>();

            Log.LogInfo($"Components: {components.Length}");

            foreach (var plugin in components)
            {
                Log.LogInfo($"Component: {plugin.name}");
            }
            _instance = null;
            _harmony = null;
        }
    }
}