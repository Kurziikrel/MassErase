﻿using BepInEx.Configuration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MassErase.Configuration
{
    public class ConfigRegistry
    {
        public ConfigEntry<float> MassEraseMain;
        public ConfigEntry<float> MassEraseMinSize;
        public ConfigEntry<float> MassEraseMaxSize;

        private ConfigFile configFile;
        private string _configurationFileName;

        public ConfigRegistry(ConfigFile config, string pluginId)
        {
            configFile = config;
            _configurationFileName = pluginId + ".cfg";
        }

        public void SetupConfigs()
        {
            MassEraseMain = configFile.Bind("MassErase", "MassEraseMain", 50f,
                new ConfigDescription("Adjusts MasssErase", new AcceptableValueRange<float>(0f, 50f)));

            MassEraseMinSize = configFile.Bind("MassErase", "MassEraseMinSize", 50f,
                new ConfigDescription("Adjusts the MassEraseMinSize", new AcceptableValueRange<float>(0f, 50f)));

            MassEraseMaxSize = configFile.Bind("MassErase", "MassEraseMaxSize", 50f,
                new ConfigDescription("Adjusts the MassEraseMaxSize", new AcceptableValueRange<float>(0f, 50f)));

        }
    }
}
